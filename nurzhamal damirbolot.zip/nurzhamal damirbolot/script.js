// Функция для переключения меню
function toggleMenu() {
    document.querySelector("nav").classList.toggle("active");
}